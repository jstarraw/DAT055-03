package javaapp.Runner.States;

public class MenuState {

	public MenuState() {
		
	}
}
