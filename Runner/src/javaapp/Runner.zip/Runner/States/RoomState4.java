package javaapp.Runner.States;

public class RoomState4 {

}
